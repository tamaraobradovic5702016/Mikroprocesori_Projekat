/*(C) Umang Gajera | Power_user_EX - www.ocfreaks.com 2011-17.
More Embedded tutorials @ www.ocfreaks.com/cat/embedded

LPC2148 I2C Example - Interfacing 24LC64 EEPROM
@ http://www.ocfreaks.com/

License : GPL.*/

#include <lpc214x.h>
#include "ocfreaks_sh.h" //This contains code for UART0, printf(), initClocks()

#define I2EN (1<<6) //Enable/Disable bit
#define STA  (1<<5) //Start Set/Clear bit
#define STO  (1<<4) //Stop bit
#define SI   (1<<3) //Serial Interrupt Flag Clear bit
#define AA   (1<<2) //Assert Acknowledge Set/Clear bit

void I2C0Init(void);
bool I2C0WaitForSI(void);
void I2C0SendStart(void);
void I2C0SendStop(void);
void I2C0TX_Byte(unsigned char data);
unsigned char I2C0RX_Byte(int isLast);
unsigned char I2C0ReadEEPROM(unsigned int addresss);
bool I2C0WriteEEPROM(unsigned int address, unsigned char data);

unsigned char I2CSlaveAddr = 0x27;

int main(void)
{
	initClocks();
	PINSEL0 = 0x00;
	PINSEL1 = 0x00;
	PINSEL2 = 0x00;
	IODIR0 = 0xFFFFFFF0;
	IODIR1 = 0xFFFFFFFF;
	I2C0Init();
	
	I2C0WriteEEPROM(0x83, 0x0F);
	I2C0WriteEEPROM(0x82, 0x03 );
	I2C0WriteEEPROM(0x80, 0x83);
	unsigned char x = 0;
	unsigned char y = 0;
	while(1){
			x = I2C0ReadEEPROM(0x80);
			if ( x & (0x20) ) {
				IOCLR1 = 0xFFFFFFFF;
				x = I2C0ReadEEPROM(0x88);
				y = I2C0ReadEEPROM(0x87);
				
				if (y > 0x08) {
					IOSET1 = 0xFFFFFFFF;
				}
			}
	}
}

void I2C0Init(void){
	PINSEL0 |= (0<<7)|(1<<6)|(0<<5)|(1<<4); //Select SCL0 and SDA0
	I2C0SCLL = 300;
	I2C0SCLH = 300; //I2C0 @ 100Khz, given PCLK @ 60Mhz
	I2C0CONCLR = STA | STO | SI | AA; //Clear these bits
	I2C0CONSET = I2EN; //Enable I2C0
}

bool I2C0WaitForSI(void) //Wait till I2C0 block sets SI
{
	int timeout = 0;
	while ( !(I2C0CONSET & SI) ) //Wait till SI bit is set. This is important!
	{
		
		timeout++;
		if (timeout > 10000) return false; //In case we have some error on bus
	}
	return true; //SI has been set
}

void I2C0SendStart(void)
{
	I2C0CONCLR = STA | STO | SI | AA; //Clear everything
	I2C0CONSET = STA; //Set start bit to send a start condition
	I2C0WaitForSI(); //Wait till the SI bit is set
}

void I2C0SendStop(void)
{
	int timeout = 0;
	I2C0CONSET = STO ; //Set stop bit to send a stop condition
	I2C0CONCLR = SI;	
	while (I2C0CONSET & STO) //Wait till STOP is send. This is important! Wasted a whole day coz of this xD.
	{
		timeout++;
		if (timeout > 10000)
		{
			IOSET0 = (1 << 6);
			printf("STOP timeout!\n");
			return;
		}
	}
	I2C0CONCLR = SI;
}

void I2C0TX_Byte(unsigned char data)
{
 	I2C0DAT = data;
	I2C0CONCLR = STA | STO | SI; //Clear These to TX data
	I2C0WaitForSI(); //wait till TX is finished
}

unsigned char I2C0RX_Byte(bool isLast)
{
	if(isLast) I2C0CONCLR = AA; //Send NACK to stop; I2C block will send a STOP automatically, so no need to send STOP after sending NACK.
	else 	   I2C0CONSET = AA; //Send ACK to continue
	
	I2C0CONCLR = SI; //Clear SI to Start RX
	I2C0WaitForSI(); //wait till RX is finished
	return I2C0DAT;
}

#define checkStatus(statusCode) \
if(I2C0STAT!=statusCode) \
{ \
	printf("Failed for status code: %i(decimal), got status code: %i(decimal)\n",statusCode,I2C0STAT); \
	I2C0SendStop(); return false; \
}

bool I2C0WriteEEPROM(unsigned int startDataAddress, unsigned char data)
{
		I2C0SendStart(); //Send START on the Bus to Enter Master Mode
		checkStatus(0x08); //START sent
		
		I2C0TX_Byte(I2CSlaveAddr & 0xFE); //Send SlaveAddress + 0 to indicate a write.
		checkStatus(0x18);//SLA+W sent and ack recevied

		I2C0TX_Byte(startDataAddress); //Send Word Address High byte first. (24xx64 needs 2 word address bytes)
		checkStatus(0x28); //High byte has been sent and ACK recevied

		I2C0TX_Byte(data); //Finally send the data byte.
		checkStatus(0x28); //Data Byte has been sent and ACK recevied
		I2C0SendStop(); //Send STOP since we are done.
	return true;
}

unsigned char I2C0ReadEEPROM(unsigned int startDataAddress)
{
	unsigned char RXData = 0;
		I2C0SendStart(); //Send START on the Bus to Enter Master Mode
		checkStatus(0x08); //START sent

		I2C0TX_Byte(I2CSlaveAddr & 0xFE); //Send SlaveAddress + 0 to indicate a write.
		checkStatus(0x18);//SLA+W sent and ack recevied

		I2C0TX_Byte(startDataAddress & 0xFF); //Now send the Low byte of word Address
		checkStatus(0x28); //Low byte has been sent and ack recevied
 
		I2C0SendStart(); //Send Repeat START, since we are already in Master mode
		checkStatus(0x10); //Repeat START sent
		
		I2C0TX_Byte(I2CSlaveAddr | 0x01); //This makes SLA-RW bit to 1 which indicates read.
		checkStatus(0x40); //SLA-R has been Transmitted and ACK received.

		RXData = I2C0RX_Byte(true); //Send ACK for byte other than last byte to indicate we want to continue.
		
		return RXData;
}
