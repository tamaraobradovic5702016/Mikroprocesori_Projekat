/*
(C) Umang Gajera | Power_user_EX - www.ocfreaks.com 2011-17.
More Embedded tutorials @ www.ocfreaks.com/cat/embedded

Support header file for OCFreaks.com LPC214x Tutorial Examples

Create LPC2148 project in Keil uV5 @ http://www.ocfreaks.com/create-keil-uvision5-project-lpc2148-arm7-mcu/
GPIO Tutorial  @ http://www.ocfreaks.com/lpc2148-gpio-programming-tutorial/
TIMER Tutorial @ http://www.ocfreaks.com/lpc2148-timer-tutorial/
PWM Tutorial   @ http://www.ocfreaks.com/lpc2148-pwm-programming-tutorial/ 
UART tutorial  @ http://www.ocfreaks.com/lpc2148-uart-programming-tutorial/
ADC Tutorial   @ http://www.ocfreaks.com/lpc2148-adc-programming-tutorial/
I2C tutorial   @ http://www.ocfreaks.com/lpc2148-arm7-i2c-programming-tutorial/
Interrupt Tutorial @ http://www.ocfreaks.com/lpc2148-interrupt-tutorial/
16x2 LCD Interfacing Tutorial @ http://www.ocfreaks.com/interfacing-16x2-lcd-with-lpc2148-tutorial/
*/

#ifndef _OCF_SUPPORT_H
#define _OCF_SUPPORT_H

#include <lpc214x.h>
#include <stdarg.h>

#define PLOCK 0x00000400
#define THRE (1<<5)
#define MULVAL 15
#define DIVADDVAL 1
#define LINE_FEED 0xA
#define CAR_RETURN 0xD

void delayMS(unsigned int milliseconds);
void initClocks(void);
void setupPLL0(void);
void feedSeq(void);
void connectPLL0(void);
void initUART0(void);
void U0Write(char data);
void printf( const char *, ... );
void SWString(char * string);
void SWUInt(unsigned int dataword);
void SWInt(int num);

void initClocks(void)
{
	setupPLL0();
	feedSeq(); //sequence for locking PLL to desired freq.
	connectPLL0();
	feedSeq(); //sequence for connecting the PLL as system clock
   
	//SysClock is now ticking @ 60Mhz!
       
	VPBDIV = 0x01; // PCLK is same as CCLK i.e 60Mhz

	//PLL0 Now configured!
}

//---------PLL Related Functions :---------------

//Using PLL settings as shown in : http://www.ocfreaks.com/lpc214x-pll-tutorial-for-cpu-and-peripheral-clock/

void setupPLL0(void)
{
	//Note : Assuming 12Mhz Xtal is connected to LPC2148.
	
	PLL0CON = 0x01; 
	PLL0CFG = 0x24; 
}

void feedSeq(void)
{
	PLL0FEED = 0xAA;
	PLL0FEED = 0x55;
}

void connectPLL0(void)
{
	while( !( PLL0STAT & PLOCK ));
	PLL0CON = 0x03;
}

void delayMS(unsigned int milliseconds)
{
	/*Assuming that PLL0 has been setup with CCLK = 60Mhz and PCLK also = 60Mhz.*/
	
	T0CTCR = 0;
	T0PR = 60000; //60000 clock cycles = 1 mS @ 60Mhz

	T0TCR = 0x02; //Reset Timer
	T0TC = 0;
	T0TCR = 0x01; //Enable timer
	
	while(T0TC < milliseconds); //wait until timer counter reaches the desired delay
	
	T0TCR = 0x00; //Disable timer
}

void initUART0(void)
{
	PINSEL0 = 0x5;//(1<<18)|(1<<16);//0x5;  /* Select TxD for P0.0 and RxD for P0.1 */
	U0LCR = 3 | (1<<7) ; /* 8 bits, no Parity, 1 Stop bit | DLAB set to 1  */
	U0DLL = 110;
	U0DLM = 1;   
	U0FDR = (MULVAL<<4) | DIVADDVAL; /* MULVAL=15(bits - 7:4) , DIVADDVAL=0(bits - 3:0)  */
	U0LCR &= 0x0F; // Set DLAB=0 to lock MULVAL and DIVADDVAL
	//BaudRate is now ~9600 and we are ready for UART communication!
}

void U0Write(char data)
{
	while ( !(U0LSR & THRE ) ); // wait till the THR is empty
	// now we can write to the Tx FIFO
	U0THR = data;
}

void printf(const char *format, ...)
{
	unsigned int pos = 0;
	va_list args;
	
	va_start(args, format); 
	
	while(format[pos] != '\0')
	{
		if(format[pos] == '%')
		{
			pos++;
			
			if(format[pos] == '\0')
			{
				return;
			}
			
			switch(format[pos])
			{
				case 'd':
					SWInt(va_arg(args, int));
					break;
				case 'i':
					SWInt(va_arg(args, int));
					break;
				case 'u':
					SWUInt(va_arg(args, unsigned int));
					break;
				case 'c':
					U0Write(va_arg(args, int));
					break;
				case 's':
					SWString(va_arg(args, char *));
					break;
				default:
					U0Write(format[pos]);
			}
		}
		else if(format[pos] == '\n')
		{
			U0Write(CAR_RETURN);
			U0Write(LINE_FEED); //On windows New-Line is 'CR+LF'
		}
		else
		{
			U0Write(format[pos]);
		}
		
		pos++;
	}
    va_end(args);  
}

void SWString(char * string)
{
	unsigned int pos = 0;
	
	while( string[pos] != '\0' )
	{
		U0Write( string[pos++] );
	}
}


void SWUInt(unsigned int dataword)
{
	//NOTE : Source code for this function has been derived from Internet.
	char buffer[11];
	char temp;

	unsigned int count;
	unsigned int len;
	unsigned int halflen;
	
	//size = 1;
	
	if(dataword == 0)
	{
		buffer[0] = '0';
		buffer[1] = '\0';
	}
	else
	{
		for(count = 0; count < 10; count++)
		{
			buffer[count] = (dataword % 10) + 48;
			dataword /= 10;
			
			if (dataword == 0)
				break;
		}
		
		buffer[count + 1] = '\0';
		len = count;
		halflen = (len + 1) / 2;
		
		for(count = 0; count < halflen; count++)
		{
			temp = buffer[count];
			buffer[count] = buffer[len];
			buffer[len] = temp;
			len -= 1;
		}
	}
	
	SWString(buffer);
}

void SWInt(int num)
{
	if(num < 0)
	{
		U0Write('-');
		SWUInt(-num);
	}
	else
		SWUInt(num);
}

#endif
